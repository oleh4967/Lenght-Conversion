import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from core import LengthCore


class NativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.core = LengthCore(ROOT / 'native' / 'length_core.dll')

    def test_reference_values(self):
        for value, source, target, result in [(1,'m','cm',100),(1,'in','cm',2.54),(1,'mi','m',1609.344),(1,'nmi','m',1852),(1,'au','m',149597870700),(1,'ly','m',9460730472580800)]:
            with self.subTest(source=source,target=target):
                self.assertAlmostEqual(self.core.convert(value,source,target),result,delta=max(1e-12,result*1e-14))

    def test_all_unit_round_trips(self):
        for source in self.core.unit_ids:
            for target in self.core.unit_ids:
                with self.subTest(source=source,target=target):
                    actual=self.core.convert(self.core.convert(123.456,source,target),target,source)
                    self.assertAlmostEqual(actual,123.456,places=10)

    def test_parsing(self):
        for text,value in [('1,25',1.25),(' 2.5 ',2.5),('.5',.5),('1.2e3',1200),('-0',0)]:
            self.assertEqual(self.core.parse(text),value)
        for text in ['', '-1', '1,234.5', '1 234', 'NaN', 'Infinity', '1e999', '1e-999', '<script>', '1m']:
            with self.subTest(text=text),self.assertRaises(ValueError): self.core.parse(text)

    def test_compound(self):
        self.assertAlmostEqual(self.core.compound('5','10'),1.778,places=12)
        self.assertAlmostEqual(self.core.convert(self.core.compound('5','10'),'m','cm'),177.8,places=10)
        with self.assertRaises(ValueError): self.core.compound('-5','0')

    def test_batch_partial_errors_and_line_numbers(self):
        data=self.core.analyze({'mode':'batch','from':'m','to':'cm','batch':'1\n\n2,5\nwrong\n-1'})
        self.assertEqual([row['line'] for row in data['results']],[1,3,4,5])
        self.assertEqual(data['results'][1]['output'],250)
        self.assertIn('error',data['results'][2])
        self.assertIn('error',data['results'][3])

    def test_batch_limits(self):
        self.assertEqual(len(self.core.analyze({'mode':'batch','from':'m','to':'cm','batch':'\n'.join(['1']*1000)})['results']),1000)
        with self.assertRaises(ValueError): self.core.analyze({'mode':'batch','from':'m','to':'cm','batch':'\n'.join(['1']*1001)})

    def test_overflow_and_unknown_units(self):
        with self.assertRaises(ValueError): self.core.convert(1e308,'ly','nm')
        with self.assertRaises(ValueError): self.core.convert(1,'missing','m')
        with self.assertRaises(ValueError): self.core.analyze({'mode':'missing'})

    def test_response_is_finite_json(self):
        for mode, extra in [('single',{'value':'1e307'}),('compound',{'feet':'5','inches':'10'}),('batch',{'batch':'1\n0\n2.5'})]:
            result=self.core.analyze({'mode':mode,'from':'m','to':'m',**extra})
            json.dumps(result,allow_nan=False)

    def test_identical_visual_assets(self):
        original=ROOT.parent/'length-converter'/'dist'
        if original.exists():
            actual=(ROOT/'ui/styles.css').read_text(encoding='utf-8').split('\n',1)[1]
            expected=(original/'styles.css').read_text(encoding='utf-8').split('\n',1)[1]
            self.assertEqual(actual,expected)
            actual=(ROOT/'ui/index.html').read_text(encoding='utf-8').replace('  <script src="qwebchannel.js" defer></script>\n','')
            expected=(original/'index.html').read_text(encoding='utf-8')
            self.assertEqual(actual,expected)


if __name__ == '__main__': unittest.main(verbosity=2)
