# Length — desktop conversion workbench

Windows x64 desktop edition of the existing length converter.

## Open the application

In the ready-to-run release folder, double-click **Length.exe**. No Python installation, compiler, terminal, browser, internet connection, or dependency installation is needed on the destination computer. Keep the `_internal` directory beside `Length.exe`. To move the application, move the whole `Length` folder.

## Architecture

- **Python / PySide6:** application window, local-file loading, clipboard, persisted favorites/history/preferences and error handling.
- **C++17 / native DLL:** all input number parsing, validation, compound measurements, unit conversion and range checking. Python calls the compiled DLL through the standard-library `ctypes` ABI.
- **HTML/CSS and presentation JavaScript:** the original interface, rendered inside the Python-managed Qt WebEngine view. This deliberate hybrid keeps the existing appearance rather than approximating it with a new set of native controls. JavaScript does not perform the numerical conversions.
- **Offline resources:** original DM Sans and Manrope fonts, plus the original application icon. The application blocks outbound web requests and does not start a local HTTP server.

The original visible labels and layout are preserved, including the original browser-oriented footer wording. The desktop window adds a standard Windows title bar.

## Features

All 13 units, three input modes (single, feet and inches, batch), equivalent values, formulas, clipboard copying, precision and locale settings, two themes, favorite pairs, and manually saved history. Batch input supports up to 1,000 lines and reports invalid rows individually.

History and settings live in `%LOCALAPPDATA%\LengthWorkbench\Length\state.json`, separately from the web browser's data. Existing website favorites/history are not automatically imported. Moving or replacing the application folder does not move or reset the app's stored data.

## Source layout

`main.py` is the Python window and desktop bridge. `core.py` binds the DLL. `native/length_core.cpp` is the C++ source. `ui/` contains the original page and offline fonts. `assets/` contains the Windows icon. `tests/` contains calculation and interface-parity checks.

## Build from source

Use Python 3.12 x64 in a virtual environment, install `requirements.txt`, and run `python build.py`. The Zig toolchain is used only as a portable C++ compiler; no Zig code is part of the application. The finished app is written to `release/Length/Length.exe` with its runtime directory alongside it. Development dependencies are not needed by the finished executable.

## Troubleshooting

If a file is missing after copying, restore the complete folder from the portable ZIP. The application writes its own diagnostics to `%LOCALAPPDATA%\LengthWorkbench\Length\length.log`. The first launch may take longer while the system loads the included runtime. A second launch while the app is already running directs you to its existing taskbar window.

## Third-party components

The application includes Python, PySide6/Qt, Qt WebEngine/Chromium, libc++/LLVM components and Google Fonts. Their notices and licenses are included with the release. The DLL and Qt runtime remain separate files, and the application source is provided alongside the release.

## Repository housekeeping

Development dependencies apply only when rebuilding from source. Native DLLs are supplied as part of the existing source snapshot and are rebuilt by `build.py`.
