# Install and run Length

## Requirements

Use Windows 11 x64 and a standard user account. The supplied application includes its runtime dependencies. It runs offline and can be placed in a writable folder such as Documents.

## Start the application

1. Download `Length-Windows-x64.zip` from this repository's **Releases**.
2. Extract the entire ZIP using **Extract All** in File Explorer.
3. Open the `Length` folder.
4. Double-click `Length.exe`.

Keep the entire extracted folder together, including `_internal`. Move the complete folder when relocating the app.

To create a desktop shortcut, right-click the EXE, choose **Show more options → Send to → Desktop (create shortcut)**. Recreate the shortcut if you move its target folder.

## Saved data and backups

Settings and saved items are stored in `%LOCALAPPDATA%\LengthWorkbench\Length\state.json`.

Close the application before making a backup of this file. Moving the EXE or replacing the application folder keeps the same Windows account's saved data available. Data from the web versions is separate.

## Updates

Close the running application, extract the new release into a new folder, and start its EXE. Check that your saved data is available before removing the previous application folder.

## Troubleshooting

Extract the ZIP before launching the application. If the runtime reports a missing file, extract a fresh complete copy. The build is unsigned. If Windows or an organization policy blocks execution, retain the exact message when reporting the problem.

Diagnostic log location: `%LOCALAPPDATA%\LengthWorkbench\Length\length.log`.
