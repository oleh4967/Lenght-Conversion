# Clean-system test checklist

## Test environment

Use a fresh Windows 11 x64 virtual machine, Windows Sandbox if available, or another test computer. Use a standard user account with no Python, Qt, VS Code or compiler installed. Transfer only `Length-Windows-x64.zip`.

This checklist is a manual validation procedure. A separate clean Windows VM was not used for the existing local checks. Previous checks used the development computer and the compiled applications.

## Manual checks

1. Extract the ZIP into a folder whose path contains spaces.
2. Double-click `Length.exe` and confirm that its English interface opens.
3. Convert 1 metre to 100 centimetres and 5 feet 10 inches to 177.8 centimetres.
4. Copy a result or color and paste it into Notepad.
5. Save an item, close the application, reopen it and confirm that the item is restored.
6. Move the extracted application folder and start the EXE again.
7. Repeat the main workflow with the guest network disconnected.
8. Record the Windows version, application release, display scale and any exact error message.

## Additional checks

- Test a batch containing `1`, `2.5` and `invalid`. Valid rows should convert and invalid input should receive an error.
- Test decimal commas and scientific notation.
- Check light/dark themes, precision settings and a restored history entry.
- Keep `_internal` alongside the EXE throughout the tests.
