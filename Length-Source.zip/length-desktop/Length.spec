from pathlib import Path

root = Path(SPECPATH)
a = Analysis(
    [str(root / 'main.py')],
    pathex=[str(root)],
    binaries=[(str(root / 'native' / 'length_core.dll'), 'native')],
    datas=[(str(root / 'ui'), 'ui'), (str(root / 'assets'), 'assets')],
    hiddenimports=[],
    hookspath=[],
    excludes=['tkinter', 'numpy', 'pandas', 'matplotlib', 'PyQt5', 'PyQt6'],
    noarchive=False,
)
# Qt uses Windows' ICU API. Do not accidentally bundle a version-suffixed ICU
# from unrelated tools on PATH (for example Poppler), which breaks Qt startup.
a.binaries = [entry for entry in a.binaries if Path(entry[0]).name.lower() not in {'icuuc.dll', 'icuin.dll', 'icudt.dll'}]
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [], exclude_binaries=True,
    name='Length', debug=False, strip=False, upx=False, console=False,
    icon=str(root / 'assets' / 'length.ico'),
)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name='Length')
