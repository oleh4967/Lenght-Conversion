"""Reproducible Windows build. Run with the project's development Python."""
from pathlib import Path
import os
import subprocess
import sys

root = Path(__file__).resolve().parent
work = root / 'build-cache'
work.mkdir(exist_ok=True)
env = dict(os.environ, ZIG_GLOBAL_CACHE_DIR=str(work / 'zig-global'), ZIG_LOCAL_CACHE_DIR=str(work / 'zig-local'))
subprocess.check_call([sys.executable, '-m', 'ziglang', 'c++', '-target', 'x86_64-windows-gnu', '-std=c++17', '-O2', '-shared', '-o', str(root / 'native/length_core.dll'), str(root / 'native/length_core.cpp')], env=env)
subprocess.check_call([sys.executable, str(root / 'tests/test_core.py')])
subprocess.check_call([sys.executable, '-m', 'PyInstaller', '--noconfirm', '--distpath', str(root / 'release'), '--workpath', str(work / 'pyinstaller'), str(root / 'Length.spec')])
print('Ready: ' + str(root / 'release/Length/Length.exe'))
