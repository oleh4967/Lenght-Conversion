"""Typed Python binding to the separately compiled C++ conversion library."""
from __future__ import annotations
import ctypes
import json
from pathlib import Path


class LengthCore:
    def __init__(self, library: Path):
        self.dll = ctypes.CDLL(str(library.resolve()))
        result = ctypes.POINTER(ctypes.c_double)
        for name in ("lc_last_error", "lc_units_json", "lc_version"):
            getattr(self.dll, name).restype = ctypes.c_char_p
            getattr(self.dll, name).argtypes = []
        self.dll.lc_parse.argtypes = [ctypes.c_char_p, result]
        self.dll.lc_compound.argtypes = [ctypes.c_char_p, ctypes.c_char_p, result]
        self.dll.lc_convert.argtypes = [ctypes.c_double, ctypes.c_char_p, ctypes.c_char_p, result]
        for name in ("lc_parse", "lc_compound", "lc_convert"):
            getattr(self.dll, name).restype = ctypes.c_int
        self.units = json.loads(self.dll.lc_units_json().decode("utf-8"))
        self.unit_ids = {unit["id"] for unit in self.units}

    def _call(self, name, *args):
        output = ctypes.c_double()
        if not getattr(self.dll, name)(*args, ctypes.byref(output)):
            raise ValueError(self.dll.lc_last_error().decode("utf-8"))
        return output.value

    def parse(self, value):
        return self._call("lc_parse", str(value).encode("utf-8"))

    def convert(self, value, source, target):
        return self._call("lc_convert", value, source.encode("utf-8"), target.encode("utf-8"))

    def compound(self, feet, inches):
        return self._call("lc_compound", str(feet).encode("utf-8"), str(inches).encode("utf-8"))

    def analyze(self, request):
        source, target = request.get("from", "m"), request.get("to", "cm")
        if source not in self.unit_ids or target not in self.unit_ids:
            raise ValueError("Choose valid length units.")
        mode = request.get("mode", "single")
        data = {}
        if mode == "batch":
            lines = str(request.get("batch", "")).split("\n")
            if len(lines) > 1000:
                raise ValueError("Please use no more than 1,000 rows at a time.")
            rows, first = [], None
            for index, text in enumerate(lines):
                if not text.strip():
                    continue
                row = {"text": text, "line": index + 1}
                try:
                    row["input"] = self.parse(text)
                    row["output"] = self.convert(row["input"], source, target)
                    if first is None:
                        first = row
                except ValueError as error:
                    row["error"] = str(error)
                rows.append(row)
            if not rows:
                raise ValueError("Enter at least one measurement, one per line.")
            if first is None:
                raise ValueError(f"No valid measurements. Row {rows[0]['line']}: {rows[0]['error']}")
            value, result = first["input"], first["output"]
            data["results"] = rows
        elif mode == "compound":
            source = "m"
            data["feet"] = self.parse(request.get("feet", ""))
            data["inches"] = self.parse(request.get("inches", ""))
            value = self.compound(request.get("feet", ""), request.get("inches", ""))
            result = self.convert(value, source, target)
        elif mode == "single":
            value = self.parse(request.get("value", ""))
            result = self.convert(value, source, target)
        else:
            raise ValueError("Choose a valid input mode.")
        equivalents = {}
        for unit in self.units:
            try:
                equivalents[unit["id"]] = self.convert(value, source, unit["id"])
            except ValueError:
                equivalents[unit["id"]] = None
        data.update(value=value, result=result, source=source, target=target,
                    equivalents=equivalents, factor=self.convert(1, source, target))
        return data
