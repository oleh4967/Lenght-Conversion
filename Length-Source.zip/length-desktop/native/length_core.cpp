#include <algorithm>
#include <cerrno>
#include <cmath>
#include <cstdlib>
#include <regex>
#include <stdexcept>
#include <string>

#ifdef _WIN32
#define API extern "C" __declspec(dllexport)
#else
#define API extern "C" __attribute__((visibility("default")))
#endif

namespace {
thread_local std::string error_message;
struct Unit { const char* id; double factor; };
const Unit units[] = {{"mm",.001},{"cm",.01},{"m",1},{"km",1000},{"in",.0254},{"ft",.3048},{"yd",.9144},{"mi",1609.344},{"nmi",1852},{"um",1e-6},{"nm",1e-9},{"au",149597870700.0},{"ly",9460730472580800.0}};
double factor(const std::string& id) {
    for (const auto& unit : units) if (id == unit.id) return unit.factor;
    throw std::invalid_argument("Choose valid length units.");
}
double parse(std::string text) {
    const auto first = text.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) throw std::invalid_argument("Enter a measurement to get started.");
    text = text.substr(first, text.find_last_not_of(" \t\r\n") - first + 1);
    if (text.size() > 512) throw std::invalid_argument("This measurement is too long.");
    static const std::regex number(R"(^[+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+)(?:[eE][+-]?\d+)?$)");
    if (!std::regex_match(text, number)) throw std::invalid_argument("Use a number with a decimal point or comma, without thousands separators.");
    std::replace(text.begin(), text.end(), ',', '.');
    errno = 0;
    const double value = std::strtod(text.c_str(), nullptr);
    if (!std::isfinite(value)) throw std::out_of_range("This number is too large. Try a smaller value.");
    if (value < 0) throw std::invalid_argument("Length must be zero or greater.");
    if (value == 0) {
        const auto mantissa = text.substr(0, text.find_first_of("eE"));
        if (mantissa.find_first_of("123456789") != std::string::npos) throw std::out_of_range("This number is too small to represent.");
    }
    return value == 0 ? 0 : value;
}
template<class F> int execute(double* output, F action) noexcept {
    try {
        error_message.clear();
        if (!output) throw std::invalid_argument("Missing output buffer.");
        *output = action();
        return 1;
    } catch (const std::exception& error) { error_message = error.what(); return 0; }
    catch (...) { error_message = "An unexpected calculation error occurred."; return 0; }
}
}

API const char* lc_last_error() noexcept { return error_message.c_str(); }
API const char* lc_version() noexcept { return "1.0.0 / C++17"; }
API int lc_parse(const char* text, double* output) noexcept {
    return execute(output, [&] { if (!text) throw std::invalid_argument("Enter a measurement."); return parse(text); });
}
API int lc_convert(double value, const char* from, const char* to, double* output) noexcept {
    return execute(output, [&] {
        if (!from || !to) throw std::invalid_argument("Choose valid length units.");
        if (!std::isfinite(value) || value < 0) throw std::invalid_argument("Enter a finite, non-negative length.");
        const double ratio = factor(from) / factor(to);
        const double result = value * ratio;
        if (!std::isfinite(result)) throw std::out_of_range("The converted value is too large to display.");
        if (value != 0 && result == 0) throw std::out_of_range("The converted value is too small to represent.");
        return result;
    });
}
API int lc_compound(const char* feet, const char* inches, double* output) noexcept {
    return execute(output, [&] {
        if (!feet || !inches) throw std::invalid_argument("Enter feet and inches.");
        const double result = parse(feet) * .3048 + parse(inches) * .0254;
        if (!std::isfinite(result)) throw std::out_of_range("This measurement is too large.");
        return result;
    });
}
API const char* lc_units_json() noexcept {
    return R"JSON([{"id":"mm","name":"Millimeters","symbol":"mm","factor":0.001},{"id":"cm","name":"Centimeters","symbol":"cm","factor":0.01},{"id":"m","name":"Meters","symbol":"m","factor":1},{"id":"km","name":"Kilometers","symbol":"km","factor":1000},{"id":"in","name":"Inches","symbol":"in","factor":0.0254},{"id":"ft","name":"Feet","symbol":"ft","factor":0.3048},{"id":"yd","name":"Yards","symbol":"yd","factor":0.9144},{"id":"mi","name":"Miles","symbol":"mi","factor":1609.344},{"id":"nmi","name":"Nautical miles","symbol":"nmi","factor":1852},{"id":"um","name":"Micrometers","symbol":"µm","factor":0.000001,"rare":true},{"id":"nm","name":"Nanometers","symbol":"nm","factor":0.000000001,"rare":true},{"id":"au","name":"Astronomical units","symbol":"au","factor":149597870700,"rare":true},{"id":"ly","name":"Light-years","symbol":"ly","factor":9460730472580800,"rare":true}])JSON";
}
