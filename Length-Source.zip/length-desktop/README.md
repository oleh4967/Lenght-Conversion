# Length

An offline length conversion workbench for Windows.

**[Download for Windows x64](../../releases/latest/download/Length-Windows-x64.zip)**

## Quick start

1. Download `Length-Windows-x64.zip` using the button above.
2. Right-click the ZIP in File Explorer and choose **Extract All**.
3. Open the extracted `Length` folder and double-click **`Length.exe`**.

The release includes Python, Qt and the required libraries. Use the downloadable application ZIP to run the program. GitHub's **Code → Download ZIP** downloads the source code.

Tested on Windows 11 x64. The interface and documentation are in English.

## Features

- Convert between 13 units with live equivalent values.
- Work with single measurements, feet and inches, or batches of up to 1,000 lines.
- Copy results, inspect formulas and customize precision, number formatting and themes.
- Save favorite conversion pairs and manually save recent conversions.

## Documentation

- [Installation, updates and local data](docs/INSTALLATION.md)
- [Testing on a clean Windows system](docs/TESTING.md)
- [Build from source](docs/DEVELOPMENT.md)

## Implementation

Python/PySide6 hosts the original HTML/CSS interface in Qt WebEngine. A compiled C++17 DLL performs parsing, validation and length conversions.

Third-party notices accompany the downloadable application.
