"""Length desktop: Python/PySide6 window, exact web UI, native C++ calculation engine."""
from __future__ import annotations
import json
import logging
import os
from pathlib import Path
import sys
import tempfile

from PySide6.QtCore import QByteArray, QBuffer, QIODevice, QObject, QStandardPaths, QUrl, Slot, Qt, QLockFile
from PySide6.QtGui import QIcon, QAction, QKeySequence
from PySide6.QtWidgets import QApplication, QMainWindow, QMessageBox
from PySide6.QtWebChannel import QWebChannel
from PySide6.QtWebEngineCore import QWebEngineUrlScheme, QWebEngineUrlSchemeHandler, QWebEngineUrlRequestJob, QWebEngineProfile, QWebEnginePage, QWebEngineSettings, QWebEngineUrlRequestInterceptor
from PySide6.QtWebEngineWidgets import QWebEngineView
from core import LengthCore

ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))


class LocalContent(QWebEngineUrlSchemeHandler):
    def requestStarted(self, request):
        if request.requestUrl().host() != 'app':
            request.fail(QWebEngineUrlRequestJob.Error.UrlNotFound)
            return
        relative = request.requestUrl().path().lstrip('/') or 'index.html'
        base = (ROOT / 'ui').resolve()
        path = (base / relative).resolve()
        if not path.is_relative_to(base) or not path.is_file():
            request.fail(QWebEngineUrlRequestJob.Error.UrlNotFound)
            return
        types = {'.html': b'text/html', '.css': b'text/css', '.js': b'application/javascript', '.png': b'image/png', '.woff2': b'font/woff2'}
        buffer = QBuffer(request)
        buffer.setData(QByteArray(path.read_bytes()))
        buffer.open(QIODevice.OpenModeFlag.ReadOnly)
        request.reply(types.get(path.suffix, b'application/octet-stream'), buffer)


class OfflineOnly(QWebEngineUrlRequestInterceptor):
    def interceptRequest(self, info):
        url = info.requestUrl()
        if url.scheme() == 'file':
            if not Path(url.toLocalFile()).resolve().is_relative_to((ROOT / 'ui').resolve()):
                info.block(True)
        elif url.scheme() not in ('data', 'blob', 'about'):
            info.block(True)


class Page(QWebEnginePage):
    def acceptNavigationRequest(self, url, kind, is_main_frame):
        return url.scheme() == 'file' and Path(url.toLocalFile()).resolve().is_relative_to((ROOT / 'ui').resolve())

    def javaScriptConsoleMessage(self, level, message, line, source):
        logging.info('UI %s:%s %s', source, line, message)


class Bridge(QObject):
    def __init__(self, core, state_path, parent=None):
        super().__init__(parent)
        self.core, self.state_path = core, state_path

    def _json(self, value):
        return json.dumps(value, ensure_ascii=False, allow_nan=False)

    @Slot(result=str)
    def initialize(self):
        state, warning = {}, ''
        try:
            if self.state_path.exists():
                if self.state_path.stat().st_size > 2_000_000:
                    raise ValueError('Settings file is too large')
                candidate = json.loads(self.state_path.read_text(encoding='utf-8'))
                if isinstance(candidate, dict):
                    state = candidate
        except (OSError, ValueError):
            logging.exception('Could not load saved state')
            warning = 'Saved settings could not be read. You can continue with default settings.'
        return self._json({'units': self.core.units, 'state': state, 'warning': warning})

    @Slot(str, result=str)
    def analyze(self, payload):
        try:
            if len(payload) > 300_000:
                raise ValueError('This input is too large. Use no more than 1,000 short rows.')
            return self._json({'ok': True, 'data': self.core.analyze(json.loads(payload))})
        except (ValueError, TypeError, KeyError) as error:
            return self._json({'ok': False, 'error': str(error)})
        except Exception:
            logging.exception('Native calculation failed')
            return self._json({'ok': False, 'error': 'An unexpected calculation error occurred.'})

    @Slot(str, result=str)
    def saveState(self, payload):
        temporary = None
        try:
            if len(payload) > 2_000_000:
                raise ValueError('Saved data is too large.')
            value = json.loads(payload)
            if not isinstance(value, dict):
                raise ValueError('Invalid settings.')
            self.state_path.parent.mkdir(parents=True, exist_ok=True)
            fd, temporary = tempfile.mkstemp(prefix='state-', suffix='.tmp', dir=self.state_path.parent)
            with os.fdopen(fd, 'w', encoding='utf-8') as handle:
                json.dump(value, handle, ensure_ascii=False, allow_nan=False)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.state_path)
            return self._json({'ok': True})
        except (OSError, ValueError):
            logging.exception('Could not save settings')
            if temporary:
                Path(temporary).unlink(missing_ok=True)
            return self._json({'ok': False, 'error': 'Settings could not be saved. Changes remain available for this visit.'})

    @Slot(str, result=bool)
    def copyText(self, text):
        QApplication.clipboard().setText(text)
        return True


class Window(QMainWindow):
    def __init__(self, data_path):
        super().__init__()
        self.setWindowTitle('Length — Conversion workbench')
        self.setWindowIcon(QIcon(str(ROOT / 'assets' / 'length.ico')))
        self.resize(1280, 920)
        self.setMinimumSize(420, 620)
        self.profile = QWebEngineProfile(self)
        self.interceptor = OfflineOnly(self.profile)
        self.profile.setUrlRequestInterceptor(self.interceptor)
        self.profile.setHttpCacheType(QWebEngineProfile.HttpCacheType.MemoryHttpCache)
        self.profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.NoPersistentCookies)
        self.web = QWebEngineView(self)
        self.page = Page(self.profile, self.web)
        self.web.setPage(self.page)
        self.web.setContextMenuPolicy(Qt.ContextMenuPolicy.NoContextMenu)
        self.page.settings().setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, False)
        self.page.settings().setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanOpenWindows, False)
        self.core = LengthCore(ROOT / 'native' / 'length_core.dll')
        self.bridge = Bridge(self.core, data_path / 'state.json', self)
        self.channel = QWebChannel(self.page)
        self.channel.registerObject('desktop', self.bridge)
        self.page.setWebChannel(self.channel)
        self.setCentralWidget(self.web)
        self.page.loadFinished.connect(self.loaded)
        self.page.loadStarted.connect(lambda: logging.info('Loading desktop interface'))
        self.web.load(QUrl.fromLocalFile(str(ROOT / 'ui' / 'index.html')))
        reload_action = QAction(self)
        reload_action.setShortcut(QKeySequence('Ctrl+R'))
        reload_action.triggered.connect(self.web.reload)
        self.addAction(reload_action)

    def loaded(self, ok):
        logging.info('Interface load finished: %s', ok)
        if not ok:
            QMessageBox.critical(self, 'Length', 'The interface could not be loaded. Keep the application folder and its _internal folder together.')


def main():
    scheme = QWebEngineUrlScheme(b'length')
    scheme.setSyntax(QWebEngineUrlScheme.Syntax.HostAndPort)
    scheme.setDefaultPort(0)
    scheme.setFlags(QWebEngineUrlScheme.Flag.SecureScheme | QWebEngineUrlScheme.Flag.LocalScheme | QWebEngineUrlScheme.Flag.LocalAccessAllowed | QWebEngineUrlScheme.Flag.CorsEnabled)
    QWebEngineUrlScheme.registerScheme(scheme)
    QApplication.setOrganizationName('LengthWorkbench')
    QApplication.setApplicationName('Length')
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon(str(ROOT / 'assets' / 'length.ico')))
    data_path = Path(QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppLocalDataLocation))
    data_path.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(filename=str(data_path / 'length.log'), level=logging.INFO, encoding='utf-8')
    lock = QLockFile(str(data_path / 'length.lock'))
    if not lock.tryLock(0):
        QMessageBox.information(None, 'Length', 'Length is already open. Select its window on the taskbar.')
        return 0
    try:
        window = Window(data_path)
        window.show()
        return app.exec()
    except Exception as error:
        logging.exception('Startup failed')
        QMessageBox.critical(None, 'Length could not start', f'{error}\n\nSee length.log in {data_path}')
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
