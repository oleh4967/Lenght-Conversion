'use strict';
// Presentation only. Every numeric parse and conversion is performed by the C++ DLL.
async function startDesktop(bridge, bootstrap) {

  const $ = id => document.getElementById(id);
  const units = bootstrap.units;
  const unit = id => units.find(item => item.id === id);
  const format = (value, precision = 'auto', locale = 'en-US') => {
    const digits = precision === 'auto' ? 8 : Number(precision);
    const scientific = value !== 0 && (Math.abs(value) >= 1e12 || Math.abs(value) < Math.pow(10, -digits));
    return new Intl.NumberFormat(locale, scientific ? { notation: 'scientific', maximumFractionDigits: digits } : { minimumFractionDigits: precision === 'auto' ? 0 : digits, maximumFractionDigits: digits }).format(value);
  };
  let renderSequence = 0;
  const native = (method, value) => new Promise(resolve => bridge[method](value, resolve));
  const key = 'length-workbench-v1';
  const precisionOptions = ['auto', '0', '2', '4', '6', '8', '12'];
  const localeOptions = ['en-US', 'de-DE', 'fr-FR'];
  let storageAvailable = true;
  let stored = bootstrap.state || {};
  if (typeof stored !== 'object') stored = {};
  const validPair = pair => pair && unit(pair.from) && unit(pair.to);
  const validHistory = item => item && ['single', 'compound', 'batch'].includes(item.mode)
    && validPair(item) && typeof item.value === 'string' && typeof item.feet === 'string'
    && typeof item.inches === 'string' && typeof item.batch === 'string'
    && typeof item.label === 'string' && Number.isFinite(item.time);
  const state = {
    mode: 'single',
    from: 'm', to: 'cm',
    precision: precisionOptions.includes(stored.precision) ? stored.precision : 'auto',
    locale: localeOptions.includes(stored.locale) ? stored.locale : 'en-US',
    theme: ['light', 'dark'].includes(stored.theme) ? stored.theme : (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'),
    favorites: Array.isArray(stored.favorites) ? stored.favorites.filter(validPair).slice(0, 12) : [{ from: 'cm', to: 'in' }, { from: 'm', to: 'ft' }],
    history: Array.isArray(stored.history) ? stored.history.filter(validHistory).slice(0, 20) : []
  };
  let current = null;
  let toastTimer;
  const fmt = n => format(n, state.precision, state.locale);
  const raw = n => n.toString();

  function toast(message) {
    $('toast').textContent = message;
    $('toast').hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { $('toast').hidden = true; }, 3200);
  }
  function persist() {
    const snapshot = { precision: state.precision, locale: state.locale, theme: state.theme, favorites: state.favorites, history: state.history };
    native('saveState', JSON.stringify(snapshot)).then(response => {
      const saved = JSON.parse(response);
      storageAvailable = saved.ok;
      if (!saved.ok) toast(saved.error);
    });
  }
  function make(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }
  async function copy(text) {
    const copied = await native('copyText', text);
    toast(copied ? 'Copied to clipboard' : 'Copy unavailable. Select and copy the result manually.');
  }
  function setTheme() {
    document.documentElement.dataset.theme = state.theme;
    $('theme-toggle').setAttribute('aria-label', `Switch to ${state.theme === 'dark' ? 'light' : 'dark'} theme`);
  }
  function setMode(mode) {
    state.mode = mode;
    document.querySelectorAll('[data-mode]').forEach(button => {
      const selected = button.dataset.mode === mode;
      button.setAttribute('aria-selected', String(selected));
      button.tabIndex = selected ? 0 : -1;
      $(`input-${button.dataset.mode}`).hidden = !selected;
    });
    $('from-unit').disabled = mode === 'compound';
    if (mode === 'compound') { state.from = 'ft'; $('from-unit').value = 'ft'; }
    render();
  }
  function sourceLabel(value) {
    if (state.mode === 'compound') return `${$('feet-input').value} ft ${$('inches-input').value} in`;
    return `${fmt(value)} ${unit(state.from).symbol}`;
  }
  function renderEquivalents(equivalents) {
    $('equivalents').replaceChildren();
    $('rare-equivalents').replaceChildren();
    units.forEach(item => {
      const output = equivalents[item.id] ?? null;
      const row = make('div', 'equivalent-row');
      const name = make('span', 'unit-name', item.name);
      name.append(make('span', 'unit-symbol', item.symbol));
      const formatted = output === null ? 'Out of range' : fmt(output);
      const number = make('span', 'unit-value', formatted);
      const button = make('button', 'row-copy', '⧉');
      button.type = 'button';
      button.setAttribute('aria-label', `Copy value in ${item.name.toLowerCase()}`);
      button.disabled = output === null;
      button.addEventListener('click', () => copy(`${formatted} ${item.symbol}`));
      row.append(name, number, button);
      $(item.rare ? 'rare-equivalents' : 'equivalents').append(row);
    });
  }
  async function render() {
    const sequence = ++renderSequence;
    state.from = $('from-unit').value;
    state.to = $('to-unit').value;
    current = null;
    $('input-error').hidden = true;
    $('batch-results').hidden = state.mode !== 'batch';
    $('batch-results').replaceChildren();
    const from = state.mode === 'compound' ? 'm' : state.from;
    const to = state.to;
    try {
      const request = { mode: state.mode, from: state.from, to: state.to, value: $('value-input').value, feet: $('feet-input').value, inches: $('inches-input').value, batch: $('batch-input').value };
      const response = JSON.parse(await native('analyze', JSON.stringify(request)));
      if (sequence !== renderSequence) return;
      if (!response.ok) throw new Error(response.error);
      const data = response.data;
      let value;
      let result;
      if (state.mode === 'batch') {
        const results = data.results;
        value = data.value;
        result = data.result;
        const good = results.filter(row => !row.error).length;
        $('result').textContent = `${good} ${good === 1 ? 'value' : 'values'}`;
        $('result-unit').textContent = `converted to ${unit(to).name.toLowerCase()}`;
        $('result-state').textContent = good === results.length ? '● Live conversion' : `${results.length - good} invalid rows`;
        results.forEach(row => {
          const element = make('div', `batch-row${row.error ? ' batch-error' : ''}`);
          element.append(make('span', '', `Row ${row.line}: ${row.text} ${unit(from).symbol}`), make('span', '', row.error || `${fmt(row.output)} ${unit(to).symbol}`));
          $('batch-results').append(element);
        });
        current = { value, result, from, to, results, copy: results.map(row => row.error ? `Row ${row.line}: ${row.error}` : `${row.text} ${unit(from).symbol} = ${fmt(row.output)} ${unit(to).symbol}`).join('\n') };
        $('equivalent-caption').textContent = 'Equivalent values for the first valid row';
        $('copy-result').firstChild.textContent = 'Copy all ';
      } else {
        value = data.value;
        result = data.result;
        $('result').textContent = fmt(result);
        $('result-unit').textContent = unit(to).name.toLowerCase();
        $('result-state').textContent = '● Live conversion';
        $('copy-result').firstChild.textContent = 'Copy result ';
        $('equivalent-caption').textContent = `Equivalent values for ${sourceLabel(value)}`;
        current = { value, result, from, to, copy: `${fmt(result)} ${unit(to).symbol}` };
      }
      $('copy-result').disabled = false;
      $('save-history').disabled = false;
      renderEquivalents(data.equivalents);
      const factor = data.factor;
      $('formula').textContent = state.mode === 'compound'
        ? `(${raw(data.feet)} × 0.3048 + ${raw(data.inches)} × 0.0254) m ÷ ${unit(to).factor} = ${fmt(result)} ${unit(to).symbol}`
        : `${raw(value)} ${unit(from).symbol} × ${raw(factor)} = ${fmt(result)} ${unit(to).symbol}${state.mode === 'batch' ? ' · first valid row' : ''}`;
    } catch (error) {
      $('input-error').textContent = error.message;
      $('input-error').hidden = false;
      $('result').textContent = '—';
      $('result-unit').textContent = 'Waiting for a valid measurement';
      $('result-state').textContent = 'Check your input';
      $('batch-results').replaceChildren();
      $('copy-result').disabled = true;
      $('save-history').disabled = true;
      $('equivalents').replaceChildren(make('p', 'empty-state', 'Enter a valid measurement to see equivalent values.'));
      $('rare-equivalents').replaceChildren();
      $('formula').textContent = 'The conversion formula will appear here.';
      $('equivalent-caption').textContent = 'Equivalent values for your measurement';
    }
    const favorite = state.favorites.some(pair => pair.from === state.from && pair.to === state.to);
    $('save-pair').textContent = state.mode === 'compound' ? '☆ Use single mode to save a pair' : (favorite ? '★ Pair in favorites' : '☆ Favorite pair');
    $('save-pair').disabled = state.mode === 'compound' || favorite;
  }
  function renderFavorites() {
    $('favorites').replaceChildren();
    if (!state.favorites.length) $('favorites').append(make('p', 'empty-state', 'Keep your go-to conversions a click away.'));
    state.favorites.forEach((pair, index) => {
      const row = make('div', 'favorite-row');
      const open = make('button', 'favorite-open', `${unit(pair.from).symbol}  →  ${unit(pair.to).symbol}`);
      open.setAttribute('aria-label', `Convert ${unit(pair.from).name.toLowerCase()} to ${unit(pair.to).name.toLowerCase()}`);
      open.addEventListener('click', () => {
        $('from-unit').value = pair.from;
        $('to-unit').value = pair.to;
        if (state.mode === 'compound') setMode('single'); else render();
      });
      const remove = make('button', 'remove-favorite', '×');
      remove.setAttribute('aria-label', `Remove ${unit(pair.from).symbol} to ${unit(pair.to).symbol} from favorites`);
      remove.addEventListener('click', () => { state.favorites.splice(index, 1); persist(); renderFavorites(); render(); });
      row.append(open, remove);
      $('favorites').append(row);
    });
  }
  function renderHistory() {
    $('history').replaceChildren();
    $('clear-history').disabled = !state.history.length;
    if (!state.history.length) $('history').append(make('p', 'empty-state', 'A fresh start. Save a conversion to revisit it here.'));
    state.history.forEach(item => {
      const button = make('button', 'history-item', item.label);
      button.append(make('small', '', new Date(item.time).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })));
      button.setAttribute('aria-label', `Restore conversion: ${item.label}`);
      button.addEventListener('click', () => {
        $('value-input').value = item.value;
        $('feet-input').value = item.feet;
        $('inches-input').value = item.inches;
        $('batch-input').value = item.batch;
        $('from-unit').value = item.from;
        $('to-unit').value = item.to;
        setMode(item.mode);
        $('converter-heading').scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth', block: 'start' });
      });
      $('history').append(button);
    });
  }
  units.forEach(item => {
    ['from-unit', 'to-unit'].forEach(id => {
      const option = make('option', '', `${item.name} (${item.symbol})`);
      option.value = item.id;
      $(id).append(option);
    });
  });
  $('from-unit').value = state.from;
  $('to-unit').value = state.to;
  $('precision').value = state.precision;
  $('number-format').value = state.locale;
  ['value-input', 'feet-input', 'inches-input', 'batch-input'].forEach(id => $(id).addEventListener('input', render));
  ['from-unit', 'to-unit'].forEach(id => $(id).addEventListener('change', render));
  document.querySelectorAll('[data-mode]').forEach((button, index, buttons) => {
    button.addEventListener('click', () => setMode(button.dataset.mode));
    button.addEventListener('keydown', event => {
      let next;
      if (event.key === 'ArrowRight') next = (index + 1) % buttons.length;
      if (event.key === 'ArrowLeft') next = (index + buttons.length - 1) % buttons.length;
      if (event.key === 'Home') next = 0;
      if (event.key === 'End') next = buttons.length - 1;
      if (next !== undefined) { event.preventDefault(); buttons[next].focus(); setMode(buttons[next].dataset.mode); }
    });
  });
  $('swap').addEventListener('click', () => {
    if (state.mode === 'compound') {
      if (!current) return;
      const value = current.result;
      $('from-unit').value = state.to;
      $('to-unit').value = 'ft';
      $('value-input').value = raw(value);
      setMode('single');
    } else {
      const oldFrom = state.from;
      const oldTo = state.to;
      if (current && state.mode === 'single') $('value-input').value = raw(current.result);
      if (current && state.mode === 'batch') $('batch-input').value = current.results.map(row => row.error ? row.text : raw(row.output)).join('\n');
      $('from-unit').value = oldTo;
      $('to-unit').value = oldFrom;
      render();
    }
  });
  $('precision').addEventListener('change', () => { state.precision = $('precision').value; persist(); render(); });
  $('number-format').addEventListener('change', () => { state.locale = $('number-format').value; persist(); render(); });
  $('theme-toggle').addEventListener('click', () => { state.theme = state.theme === 'light' ? 'dark' : 'light'; setTheme(); persist(); });
  $('copy-result').addEventListener('click', () => { if (current) copy(current.copy); });
  $('save-pair').addEventListener('click', () => {
    if (state.favorites.length >= 12) { toast('You can keep up to 12 favorite pairs. Remove one to add another.'); return; }
    if (state.mode === 'compound' || state.favorites.some(pair => pair.from === state.from && pair.to === state.to)) return;
    state.favorites.push({ from: state.from, to: state.to });
    persist(); renderFavorites(); render(); toast('Pair added to favorites');
  });
  $('save-history').addEventListener('click', () => {
    if (!current) return;
    const label = state.mode === 'batch' ? `${current.results.filter(row => !row.error).length} values · ${unit(state.from).symbol} → ${unit(state.to).symbol}` : `${sourceLabel(current.value)} → ${fmt(current.result)} ${unit(state.to).symbol}`;
    state.history.unshift({ mode: state.mode, from: state.from, to: state.to, value: $('value-input').value, feet: $('feet-input').value, inches: $('inches-input').value, batch: $('batch-input').value, label, time: Date.now() });
    state.history = state.history.slice(0, 20);
    persist(); renderHistory();
    if (storageAvailable) toast('Conversion saved to history');
  });
  $('clear-history').addEventListener('click', () => { state.history = []; persist(); renderHistory(); toast('History cleared'); });
  setTheme(); renderFavorites(); renderHistory(); render();
  if (bootstrap.warning) toast(bootstrap.warning);

}
if (typeof qt !== 'undefined' && typeof QWebChannel !== 'undefined') {
  new QWebChannel(qt.webChannelTransport, channel => {
    const bridge = channel.objects.desktop;
    bridge.initialize(payload => {
      try { startDesktop(bridge, JSON.parse(payload)); }
      catch (error) { document.getElementById('result').textContent = 'Unable to initialize'; document.getElementById('input-error').textContent = error.message; document.getElementById('input-error').hidden = false; }
    });
  });
} else {
  document.getElementById('result').textContent = 'Open the Length app';
  document.getElementById('input-error').textContent = 'This desktop interface needs Length.exe. Use the original web version in a browser.';
  document.getElementById('input-error').hidden = false;
}
